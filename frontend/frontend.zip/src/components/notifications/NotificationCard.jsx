import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';

export const NotificationCard = ({ notification }) => {
  return (
    <Link
      to={`/post/${notification.postId}`}
      className="block bg-white shadow rounded-lg p-4 hover:bg-gray-50 transition-colors duration-150"
    >
      <div className="flex items-center justify-between">
        <p className="text-gray-800">{notification.message}</p>
        <span className="text-sm text-gray-500">
          {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
        </span>
      </div>
    </Link>
  );
};

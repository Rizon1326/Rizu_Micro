// import axios from 'axios';

// const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

// const api = axios.create({
//   baseURL: API_BASE_URL,
// });

// export const signup = (data) => api.post('/auth/signup', data);
// export const signin = (data) => api.post('/auth/signin', data);
// export const createPost = (data, token) =>
//   api.post('/post', data, { headers: { Authorization: `Bearer ${token}` } });
// export const getPosts = (token) =>
//   api.get('/post', { headers: { Authorization: `Bearer ${token}` } });
// export const getNotifications = (token) =>
//   api.get('/notification', { headers: { Authorization: `Bearer ${token}` } });

// export default api;
